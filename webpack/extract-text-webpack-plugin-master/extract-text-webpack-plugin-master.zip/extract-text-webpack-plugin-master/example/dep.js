require("./style2.css");
require(["./dep2"]);
