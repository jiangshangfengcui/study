require.ensure([], function() {
	require("./a.txt");
	require("./c.txt");
});
