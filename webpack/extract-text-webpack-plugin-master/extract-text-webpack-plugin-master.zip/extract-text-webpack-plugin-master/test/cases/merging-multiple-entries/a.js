require.ensure([], function() {
	require("./a.txt");
	require("./b.txt");
});
