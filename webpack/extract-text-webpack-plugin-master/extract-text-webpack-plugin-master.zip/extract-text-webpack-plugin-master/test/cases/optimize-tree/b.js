require.ensure([], function() {
	require("./b.txt");
});

b = {};
