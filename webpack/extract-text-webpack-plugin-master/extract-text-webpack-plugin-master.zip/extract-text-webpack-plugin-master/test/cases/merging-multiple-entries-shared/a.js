require.ensure([], function() {
	require("./a.txt");
});
