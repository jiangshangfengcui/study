/**
 * @author QLeelulu@gmail.com
 * @blog http://qleelulu.cnblogs.com
 */


var n2MvcServer = require('./server');
n2MvcServer.runServer();