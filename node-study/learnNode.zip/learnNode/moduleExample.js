/**
 * @author QLeelulu@gmail.com
 * @blog http://qleelulu.cnblogs.com
 */

//moduleExample.js
var myPrivate = '艳照，藏着';
exports.myPublish = '冠西的相机';
this.myPublish2 = 'this也可以哦';

console.log('moduleExample.js loaded \n');